# Read Me First
The following was discovered as part of building this project:

* The original package name 'com.example.usuarios-productos' is invalid and this project uses 'com.example.usuarios_productos' instead.

# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/4.1.3/maven-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/4.1.3/maven-plugin/build-image.html)
* [Spring Web](https://docs.spring.io/spring-boot/4.1.3/reference/web/servlet.html)
* [Validation](https://docs.spring.io/spring-boot/4.1.3/reference/io/validation.html)
* [Spring HATEOAS](https://docs.spring.io/spring-boot/4.1.3/reference/web/spring-hateoas.html)
* [Spring Data JPA](https://docs.spring.io/spring-boot/4.1.3/reference/data/sql.html#data.sql.jpa-and-spring-data)

### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)
* [Validation](https://spring.io/guides/gs/validating-form-input/)
* [Building a Hypermedia-Driven RESTful Web Service](https://spring.io/guides/gs/rest-hateoas/)
* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)
* [Accessing data with MySQL](https://spring.io/guides/gs/accessing-data-mysql/)

### Maven Parent overrides

Due to Maven's design, elements are inherited from the parent POM to the project POM.
While most of the inheritance is fine, it also inherits unwanted elements like `<license>` and `<developers>` from the parent.
To prevent this, the project POM contains empty overrides for these elements.
If you manually switch to a different parent and actually want the inheritance, you need to remove those overrides.

