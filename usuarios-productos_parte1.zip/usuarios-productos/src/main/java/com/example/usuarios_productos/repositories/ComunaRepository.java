package com.example.usuarios_productos.repositories;

import com.example.usuarios_productos.models.ComunaModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ComunaRepository extends JpaRepository<ComunaModel, Long> {

}