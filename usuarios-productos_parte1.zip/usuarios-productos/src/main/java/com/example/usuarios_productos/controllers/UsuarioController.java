package com.example.usuarios_productos.controllers;

import com.example.usuarios_productos.models.UsuarioModel;
import com.example.usuarios_productos.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<UsuarioModel>>> findAll() {

        List<EntityModel<UsuarioModel>> usuarios =
                usuarioService.findAll()
                        .stream()
                        .map(this::toModel)
                        .toList();

        return ResponseEntity.ok(
                CollectionModel.of(usuarios,
                        linkTo(methodOn(UsuarioController.class)
                                .findAll()).withSelfRel()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<UsuarioModel>> findById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                toModel(usuarioService.findById(id)));
    }

    @PostMapping
    public ResponseEntity<EntityModel<UsuarioModel>> save(
            @RequestBody UsuarioModel usuario) {

        UsuarioModel nuevo = usuarioService.save(usuario);

        return ResponseEntity.created(
                linkTo(methodOn(UsuarioController.class)
                        .findById(nuevo.getId())).toUri()
        ).body(toModel(nuevo));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<UsuarioModel>> update(
            @PathVariable Long id,
            @RequestBody UsuarioModel usuario) {

        return ResponseEntity.ok(
                toModel(usuarioService.update(id, usuario)));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<EntityModel<UsuarioModel>> patch(
            @PathVariable Long id,
            @RequestBody Map<String, Object> cambios) {

        return ResponseEntity.ok(
                toModel(usuarioService.patch(id, cambios)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {

        usuarioService.delete(id);

        return ResponseEntity.noContent().build();
    }

    private EntityModel<UsuarioModel> toModel(UsuarioModel usuario) {

        EntityModel<UsuarioModel> modelo = EntityModel.of(
                usuario,
                linkTo(methodOn(UsuarioController.class)
                        .findById(usuario.getId())).withSelfRel(),

                linkTo(methodOn(UsuarioController.class)
                        .findAll()).withRel("usuarios")
        );

        if (usuario.getDireccion() != null) {

            modelo.add(
                    linkTo(methodOn(DireccionController.class)
                            .findById(usuario.getDireccion().getId()))
                            .withRel("direccion")
            );
        }

        return modelo;
    }
}