package com.example.usuarios_productos.services;

import com.example.usuarios_productos.models.DireccionModel;
import com.example.usuarios_productos.models.ComunaModel;
import com.example.usuarios_productos.repositories.DireccionRepository;
import com.example.usuarios_productos.repositories.ComunaRepository;
import com.example.usuarios_productos.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class DireccionService {

    @Autowired
    private DireccionRepository direccionRepository;

    @Autowired
    private ComunaRepository comunaRepository;

    public List<DireccionModel> findAll() {
        return direccionRepository.findAll();
    }

    public DireccionModel findById(Long id) {
        return direccionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Direccion no encontrada"));
    }

    public DireccionModel save(DireccionModel direccion) {

        validarDireccion(direccion);

        direccion.setComuna(buscarComuna(direccion.getComuna()));
        direccion.setId(null);

        return direccionRepository.save(direccion);
    }

    public DireccionModel update(Long id, DireccionModel direccion) {

        DireccionModel existente = findById(id);

        validarDireccion(direccion);

        existente.setCalle(direccion.getCalle());
        existente.setNumero(direccion.getNumero());
        existente.setComuna(buscarComuna(direccion.getComuna()));

        return direccionRepository.save(existente);
    }

    public DireccionModel patch(Long id, Map<String, Object> cambios) {

        DireccionModel existente = findById(id);

        for (String campo : cambios.keySet()) {

            Object valor = cambios.get(campo);

            switch (campo) {

                case "calle":

                    if (!(valor instanceof String calle)) {
                        throw new IllegalArgumentException(
                                "Calle no valida");
                    }

                    existente.setCalle(calle);
                    break;

                case "numero":

                    if (!(valor instanceof String numero)) {
                        throw new IllegalArgumentException(
                                "Numero no valido");
                    }

                    existente.setNumero(numero);
                    break;

                case "comuna":

                    if (!(valor instanceof Map<?, ?> datos)
                            || !(datos.get("id") instanceof Number comunaId)) {

                        throw new IllegalArgumentException(
                                "Debe indicar el ID de la comuna");
                    }

                    ComunaModel comuna = new ComunaModel();
                    comuna.setId(comunaId.longValue());

                    existente.setComuna(buscarComuna(comuna));
                    break;

                default:
                    throw new IllegalArgumentException(
                            "Campo no permitido: " + campo);
            }
        }

        validarDireccion(existente);

        return direccionRepository.save(existente);
    }

    public void delete(Long id) {
        direccionRepository.delete(findById(id));
    }

    private ComunaModel buscarComuna(ComunaModel comuna) {

        if (comuna == null || comuna.getId() == null) {
            throw new IllegalArgumentException(
                    "La comuna es obligatoria");
        }

        return comunaRepository.findById(comuna.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "La comuna no existe"));
    }

    private void validarDireccion(DireccionModel direccion) {

        if (direccion.getCalle() == null
                || direccion.getCalle().isBlank()
                || direccion.getCalle().length() > 150) {

            throw new IllegalArgumentException("Calle no valida");
        }

        if (direccion.getNumero() == null
                || direccion.getNumero().isBlank()
                || direccion.getNumero().length() > 20) {

            throw new IllegalArgumentException("Numero no valido");
        }
    }
}