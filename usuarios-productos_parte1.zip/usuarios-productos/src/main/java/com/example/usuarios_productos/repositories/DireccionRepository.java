package com.example.usuarios_productos.repositories;

import com.example.usuarios_productos.models.DireccionModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DireccionRepository extends JpaRepository<DireccionModel, Long> {

}