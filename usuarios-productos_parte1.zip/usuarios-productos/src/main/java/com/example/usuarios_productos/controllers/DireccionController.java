package com.example.usuarios_productos.controllers;

import com.example.usuarios_productos.models.DireccionModel;
import com.example.usuarios_productos.services.DireccionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/direcciones")
public class DireccionController {

    @Autowired
    private DireccionService direccionService;

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<DireccionModel>>> findAll() {

        List<EntityModel<DireccionModel>> direcciones =
                direccionService.findAll()
                        .stream()
                        .map(this::toModel)
                        .toList();

        return ResponseEntity.ok(
                CollectionModel.of(direcciones,
                        linkTo(methodOn(DireccionController.class)
                                .findAll()).withSelfRel()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<DireccionModel>> findById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                toModel(direccionService.findById(id)));
    }

    @PostMapping
    public ResponseEntity<EntityModel<DireccionModel>> save(
            @RequestBody DireccionModel direccion) {

        DireccionModel nueva = direccionService.save(direccion);

        return ResponseEntity.created(
                linkTo(methodOn(DireccionController.class)
                        .findById(nueva.getId())).toUri()
        ).body(toModel(nueva));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<DireccionModel>> update(
            @PathVariable Long id,
            @RequestBody DireccionModel direccion) {

        return ResponseEntity.ok(
                toModel(direccionService.update(id, direccion)));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<EntityModel<DireccionModel>> patch(
            @PathVariable Long id,
            @RequestBody Map<String, Object> cambios) {

        return ResponseEntity.ok(
                toModel(direccionService.patch(id, cambios)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {

        direccionService.delete(id);

        return ResponseEntity.noContent().build();
    }

    private EntityModel<DireccionModel> toModel(DireccionModel direccion) {

        return EntityModel.of(
                direccion,
                linkTo(methodOn(DireccionController.class)
                        .findById(direccion.getId())).withSelfRel(),

                linkTo(methodOn(DireccionController.class)
                        .findAll()).withRel("direcciones"),

                linkTo(methodOn(ComunaController.class)
                        .findById(direccion.getComuna().getId()))
                        .withRel("comuna")
        );
    }
}