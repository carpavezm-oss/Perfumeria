package com.example.usuarios_productos.controllers;

import com.example.usuarios_productos.models.RegionModel;
import com.example.usuarios_productos.services.RegionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/regiones")
public class RegionController {

    @Autowired
    private RegionService regionService;

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<RegionModel>>> findAll() {

        List<EntityModel<RegionModel>> regiones = regionService.findAll()
                .stream()
                .map(this::toModel)
                .toList();

        return ResponseEntity.ok(
                CollectionModel.of(regiones,
                        linkTo(methodOn(RegionController.class)
                                .findAll()).withSelfRel()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<RegionModel>> findById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                toModel(regionService.findById(id)));
    }

    @PostMapping
    public ResponseEntity<EntityModel<RegionModel>> save(
            @RequestBody RegionModel region) {

        RegionModel nueva = regionService.save(region);

        return ResponseEntity.created(
                linkTo(methodOn(RegionController.class)
                        .findById(nueva.getId())).toUri()
        ).body(toModel(nueva));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<RegionModel>> update(
            @PathVariable Long id,
            @RequestBody RegionModel region) {

        return ResponseEntity.ok(
                toModel(regionService.update(id, region)));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<EntityModel<RegionModel>> patch(
            @PathVariable Long id,
            @RequestBody RegionModel region) {

        return ResponseEntity.ok(
                toModel(regionService.patch(id, region)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {

        regionService.delete(id);

        return ResponseEntity.noContent().build();
    }

    private EntityModel<RegionModel> toModel(RegionModel region) {

        return EntityModel.of(
                region,
                linkTo(methodOn(RegionController.class)
                        .findById(region.getId())).withSelfRel(),

                linkTo(methodOn(RegionController.class)
                        .findAll()).withRel("regiones")
        );
    }
}