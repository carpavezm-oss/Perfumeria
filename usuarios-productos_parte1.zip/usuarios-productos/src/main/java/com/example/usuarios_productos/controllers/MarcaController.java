package com.example.usuarios_productos.controllers;

import com.example.usuarios_productos.models.MarcaModel;
import com.example.usuarios_productos.services.MarcaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/marcas")
public class MarcaController {

    @Autowired
    private MarcaService marcaService;

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<MarcaModel>>> findAll() {

        List<EntityModel<MarcaModel>> marcas = marcaService.findAll()
                .stream()
                .map(this::toModel)
                .toList();

        return ResponseEntity.ok(
                CollectionModel.of(marcas,
                        linkTo(methodOn(MarcaController.class)
                                .findAll()).withSelfRel()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<MarcaModel>> findById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                toModel(marcaService.findById(id)));
    }

    @PostMapping
    public ResponseEntity<EntityModel<MarcaModel>> save(
            @RequestBody MarcaModel marca) {

        MarcaModel nueva = marcaService.save(marca);

        return ResponseEntity.created(
                linkTo(methodOn(MarcaController.class)
                        .findById(nueva.getId())).toUri()
        ).body(toModel(nueva));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<MarcaModel>> update(
            @PathVariable Long id,
            @RequestBody MarcaModel marca) {

        return ResponseEntity.ok(
                toModel(marcaService.update(id, marca)));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<EntityModel<MarcaModel>> patch(
            @PathVariable Long id,
            @RequestBody MarcaModel marca) {

        return ResponseEntity.ok(
                toModel(marcaService.patch(id, marca)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {

        marcaService.delete(id);

        return ResponseEntity.noContent().build();
    }

    private EntityModel<MarcaModel> toModel(MarcaModel marca) {

        return EntityModel.of(
                marca,
                linkTo(methodOn(MarcaController.class)
                        .findById(marca.getId())).withSelfRel(),

                linkTo(methodOn(MarcaController.class)
                        .findAll()).withRel("marcas")
        );
    }
}