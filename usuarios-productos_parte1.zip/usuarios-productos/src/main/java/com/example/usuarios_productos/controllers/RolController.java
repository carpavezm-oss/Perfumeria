package com.example.usuarios_productos.controllers;

import com.example.usuarios_productos.models.RolModel;
import com.example.usuarios_productos.services.RolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/roles")
public class RolController {

    @Autowired
    private RolService rolService;

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<RolModel>>> findAll() {

        List<EntityModel<RolModel>> roles = rolService.findAll()
                .stream()
                .map(this::toModel)
                .toList();

        return ResponseEntity.ok(
                CollectionModel.of(
                        roles,
                        linkTo(methodOn(RolController.class)
                                .findAll()).withSelfRel()
                )
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<RolModel>> findById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                toModel(rolService.findById(id)));
    }

    @PostMapping
    public ResponseEntity<EntityModel<RolModel>> save(
            @RequestBody RolModel rol) {

        RolModel nuevo = rolService.save(rol);

        return ResponseEntity.created(
                linkTo(methodOn(RolController.class)
                        .findById(nuevo.getId())).toUri()
        ).body(toModel(nuevo));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<RolModel>> update(
            @PathVariable Long id,
            @RequestBody RolModel rol) {

        return ResponseEntity.ok(
                toModel(rolService.update(id, rol)));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<EntityModel<RolModel>> patch(
            @PathVariable Long id,
            @RequestBody RolModel rol) {

        return ResponseEntity.ok(
                toModel(rolService.patch(id, rol)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(
            @PathVariable Long id) {

        rolService.delete(id);

        return ResponseEntity.noContent().build();
    }

    private EntityModel<RolModel> toModel(RolModel rol) {

        return EntityModel.of(
                rol,
                linkTo(methodOn(RolController.class)
                        .findById(rol.getId())).withSelfRel(),

                linkTo(methodOn(RolController.class)
                        .findAll()).withRel("roles")
        );
    }
}