package com.example.usuarios_productos.controllers;

import com.example.usuarios_productos.models.ProductoModel;
import com.example.usuarios_productos.services.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/productos")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<ProductoModel>>> findAll() {

        List<EntityModel<ProductoModel>> productos =
                productoService.findAll()
                        .stream()
                        .map(this::toModel)
                        .toList();

        return ResponseEntity.ok(
                CollectionModel.of(productos,
                        linkTo(methodOn(ProductoController.class)
                                .findAll()).withSelfRel()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<ProductoModel>> findById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                toModel(productoService.findById(id)));
    }

    @PostMapping
    public ResponseEntity<EntityModel<ProductoModel>> save(
            @RequestBody ProductoModel producto) {

        ProductoModel nuevo = productoService.save(producto);

        return ResponseEntity.created(
                linkTo(methodOn(ProductoController.class)
                        .findById(nuevo.getId())).toUri()
        ).body(toModel(nuevo));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<ProductoModel>> update(
            @PathVariable Long id,
            @RequestBody ProductoModel producto) {

        return ResponseEntity.ok(
                toModel(productoService.update(id, producto)));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<EntityModel<ProductoModel>> patch(
            @PathVariable Long id,
            @RequestBody Map<String, Object> cambios) {

        return ResponseEntity.ok(
                toModel(productoService.patch(id, cambios)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {

        productoService.delete(id);

        return ResponseEntity.noContent().build();
    }

    @GetMapping("/activos")
    public ResponseEntity<CollectionModel<EntityModel<ProductoModel>>> findActivos() {

        List<EntityModel<ProductoModel>> productos =
                productoService.findActivos()
                        .stream()
                        .map(this::toModel)
                        .toList();

        return ResponseEntity.ok(
                CollectionModel.of(productos,
                        linkTo(methodOn(ProductoController.class)
                                .findActivos()).withSelfRel()));
    }

    @GetMapping("/ofertas")
    public ResponseEntity<CollectionModel<EntityModel<ProductoModel>>> findOfertas() {

        List<EntityModel<ProductoModel>> productos =
                productoService.findOfertas()
                        .stream()
                        .map(this::toModel)
                        .toList();

        return ResponseEntity.ok(
                CollectionModel.of(productos,
                        linkTo(methodOn(ProductoController.class)
                                .findOfertas()).withSelfRel()));
    }

    @GetMapping("/buscar")
    public ResponseEntity<CollectionModel<EntityModel<ProductoModel>>> buscarPorNombre(
            @RequestParam String nombre) {

        List<EntityModel<ProductoModel>> productos =
                productoService.buscarPorNombre(nombre)
                        .stream()
                        .map(this::toModel)
                        .toList();

        return ResponseEntity.ok(
                CollectionModel.of(productos,
                        linkTo(methodOn(ProductoController.class)
                                .buscarPorNombre(nombre)).withSelfRel()));
    }

    @GetMapping("/marca/{marcaId}")
    public ResponseEntity<CollectionModel<EntityModel<ProductoModel>>> findByMarca(
            @PathVariable Long marcaId) {

        List<EntityModel<ProductoModel>> productos =
                productoService.findByMarca(marcaId)
                        .stream()
                        .map(this::toModel)
                        .toList();

        return ResponseEntity.ok(
                CollectionModel.of(productos,
                        linkTo(methodOn(ProductoController.class)
                                .findByMarca(marcaId)).withSelfRel()));
    }

    @GetMapping("/categoria/{categoriaId}")
    public ResponseEntity<CollectionModel<EntityModel<ProductoModel>>> findByCategoria(
            @PathVariable Long categoriaId) {

        List<EntityModel<ProductoModel>> productos =
                productoService.findByCategoria(categoriaId)
                        .stream()
                        .map(this::toModel)
                        .toList();

        return ResponseEntity.ok(
                CollectionModel.of(productos,
                        linkTo(methodOn(ProductoController.class)
                                .findByCategoria(categoriaId)).withSelfRel()));
    }

    @GetMapping("/categoria/nombre/{nombre}")
    public ResponseEntity<CollectionModel<EntityModel<ProductoModel>>> findByNombreCategoria(
            @PathVariable String nombre) {

        List<EntityModel<ProductoModel>> productos =
                productoService.findByNombreCategoria(nombre)
                        .stream()
                        .map(this::toModel)
                        .toList();

        return ResponseEntity.ok(
                CollectionModel.of(productos,
                        linkTo(methodOn(ProductoController.class)
                                .findByNombreCategoria(nombre)).withSelfRel()));
    }

    private EntityModel<ProductoModel> toModel(ProductoModel producto) {

        EntityModel<ProductoModel> modelo = EntityModel.of(
                producto,
                linkTo(methodOn(ProductoController.class)
                        .findById(producto.getId())).withSelfRel(),

                linkTo(methodOn(ProductoController.class)
                        .findAll()).withRel("productos"),

                linkTo(methodOn(MarcaController.class)
                        .findById(producto.getMarca().getId()))
                        .withRel("marca")
        );

        return modelo;
    }
}