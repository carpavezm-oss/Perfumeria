package com.example.usuarios_productos.repositories;

import com.example.usuarios_productos.models.CategoriaModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CategoriaRepository extends JpaRepository<CategoriaModel, Long> {

    boolean existsByNombreIgnoreCase(String nombre);

}