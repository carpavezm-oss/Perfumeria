package com.example.usuarios_productos.services;

import com.example.usuarios_productos.models.CategoriaModel;
import com.example.usuarios_productos.repositories.CategoriaRepository;
import com.example.usuarios_productos.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class CategoriaService {

    @Autowired
    private CategoriaRepository categoriaRepository;

    public List<CategoriaModel> findAll() {
        return categoriaRepository.findAll();
    }

    public CategoriaModel findById(Long id) {
        return categoriaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Categoria no encontrada"));
    }

    public CategoriaModel save(CategoriaModel categoria) {

        validarCategoria(categoria);

        if (categoriaRepository.existsByNombreIgnoreCase(
                categoria.getNombre())) {

            throw new IllegalArgumentException(
                    "La categoria ya existe");
        }

        categoria.setId(null);

        return categoriaRepository.save(categoria);
    }

    public CategoriaModel update(Long id, CategoriaModel categoria) {

        CategoriaModel existente = findById(id);

        validarCategoria(categoria);
        validarDuplicado(existente, categoria.getNombre());

        existente.setNombre(categoria.getNombre());
        existente.setDescripcion(categoria.getDescripcion());

        return categoriaRepository.save(existente);
    }

    public CategoriaModel patch(Long id, Map<String, Object> cambios) {

        CategoriaModel existente = findById(id);

        for (String campo : cambios.keySet()) {

            Object valor = cambios.get(campo);

            switch (campo) {

                case "nombre":

                    if (!(valor instanceof String nombre)
                            || nombre.isBlank()) {

                        throw new IllegalArgumentException(
                                "El nombre es obligatorio");
                    }

                    validarDuplicado(existente, nombre);

                    existente.setNombre(nombre);
                    break;

                case "descripcion":

                    if (valor != null && !(valor instanceof String)) {
                        throw new IllegalArgumentException(
                                "Descripcion no valida");
                    }

                    existente.setDescripcion((String) valor);
                    break;

                default:
                    throw new IllegalArgumentException(
                            "Campo no permitido: " + campo);
            }
        }

        validarCategoria(existente);

        return categoriaRepository.save(existente);
    }

    public void delete(Long id) {
        categoriaRepository.delete(findById(id));
    }

    private void validarCategoria(CategoriaModel categoria) {

        if (categoria.getNombre() == null
                || categoria.getNombre().isBlank()
                || categoria.getNombre().length() > 100) {

            throw new IllegalArgumentException(
                    "Nombre de categoria no valido");
        }

        if (categoria.getDescripcion() != null
                && categoria.getDescripcion().length() > 255) {

            throw new IllegalArgumentException(
                    "La descripcion supera los 255 caracteres");
        }
    }

    private void validarDuplicado(
            CategoriaModel existente, String nombre) {

        if (!existente.getNombre().equalsIgnoreCase(nombre)
                && categoriaRepository.existsByNombreIgnoreCase(nombre)) {

            throw new IllegalArgumentException(
                    "La categoria ya existe");
        }
    }
}