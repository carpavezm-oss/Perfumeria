package com.example.usuarios_productos.controllers;

import com.example.usuarios_productos.models.ComunaModel;
import com.example.usuarios_productos.services.ComunaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/comunas")
public class ComunaController {

    @Autowired
    private ComunaService comunaService;

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<ComunaModel>>> findAll() {

        List<EntityModel<ComunaModel>> comunas = comunaService.findAll()
                .stream()
                .map(this::toModel)
                .toList();

        return ResponseEntity.ok(
                CollectionModel.of(comunas,
                        linkTo(methodOn(ComunaController.class)
                                .findAll()).withSelfRel()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<ComunaModel>> findById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                toModel(comunaService.findById(id)));
    }

    @PostMapping
    public ResponseEntity<EntityModel<ComunaModel>> save(
            @RequestBody ComunaModel comuna) {

        ComunaModel nueva = comunaService.save(comuna);

        return ResponseEntity.created(
                linkTo(methodOn(ComunaController.class)
                        .findById(nueva.getId())).toUri()
        ).body(toModel(nueva));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<ComunaModel>> update(
            @PathVariable Long id,
            @RequestBody ComunaModel comuna) {

        return ResponseEntity.ok(
                toModel(comunaService.update(id, comuna)));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<EntityModel<ComunaModel>> patch(
            @PathVariable Long id,
            @RequestBody ComunaModel comuna) {

        return ResponseEntity.ok(
                toModel(comunaService.patch(id, comuna)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {

        comunaService.delete(id);

        return ResponseEntity.noContent().build();
    }

    private EntityModel<ComunaModel> toModel(ComunaModel comuna) {

        return EntityModel.of(
                comuna,
                linkTo(methodOn(ComunaController.class)
                        .findById(comuna.getId())).withSelfRel(),

                linkTo(methodOn(ComunaController.class)
                        .findAll()).withRel("comunas"),

                linkTo(methodOn(RegionController.class)
                        .findById(comuna.getRegion().getId()))
                        .withRel("region")
        );
    }
}