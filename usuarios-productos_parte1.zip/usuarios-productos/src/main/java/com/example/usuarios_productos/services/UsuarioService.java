package com.example.usuarios_productos.services;

import com.example.usuarios_productos.models.*;
import com.example.usuarios_productos.repositories.*;
import com.example.usuarios_productos.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.nio.charset.StandardCharsets;

@Service
@Transactional
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private RolRepository rolRepository;

    @Autowired
    private DireccionRepository direccionRepository;

    private final BCryptPasswordEncoder encoder =
            new BCryptPasswordEncoder();

    public List<UsuarioModel> findAll() {
        return usuarioRepository.findAll();
    }

    public UsuarioModel findById(Long id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Usuario no encontrado"));
    }

    public UsuarioModel findByCorreo(String correo) {
        return usuarioRepository.findByCorreo(correo)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Usuario no encontrado"));
    }

    public UsuarioModel save(UsuarioModel usuario) {

        validarUsuario(usuario);

        if (usuarioRepository.existsByCorreo(usuario.getCorreo())) {
            throw new IllegalArgumentException(
                    "El correo ya esta registrado");
        }

        if (usuarioRepository.existsByRut(usuario.getRut())) {
            throw new IllegalArgumentException(
                    "El RUT ya esta registrado");
        }

        validarPassword(usuario.getPassword());

        usuario.setPassword(
                encoder.encode(usuario.getPassword()));

        usuario.setId(null);
        usuario.setActivo(true);
        usuario.setRoles(obtenerRolCliente());

        usuario.setDireccion(
                buscarDireccion(usuario.getDireccion()));

        return usuarioRepository.save(usuario);
    }

    public UsuarioModel update(Long id, UsuarioModel usuario) {

        UsuarioModel existente = findById(id);

        validarUsuario(usuario);
        validarDuplicados(existente, usuario);

        existente.setRut(usuario.getRut());
        existente.setNombre(usuario.getNombre());
        existente.setApellido(usuario.getApellido());
        existente.setCorreo(usuario.getCorreo());
        existente.setTelefono(usuario.getTelefono());

        existente.setDireccion(
                buscarDireccion(usuario.getDireccion()));

        if (usuario.getPassword() != null) {

            validarPassword(usuario.getPassword());

            existente.setPassword(
                    encoder.encode(usuario.getPassword()));
        }

        return usuarioRepository.save(existente);
    }

    public UsuarioModel patch(Long id, Map<String, Object> cambios) {

        UsuarioModel existente = findById(id);

        String correoAnterior = existente.getCorreo();
        String rutAnterior = existente.getRut();

        for (String campo : cambios.keySet()) {

            Object valor = cambios.get(campo);

            switch (campo) {

                case "nombre":
                    existente.setNombre(obtenerTexto(valor));
                    break;

                case "apellido":
                    existente.setApellido(obtenerTexto(valor));
                    break;

                case "correo":
                    existente.setCorreo(obtenerTexto(valor));
                    break;

                case "rut":
                    existente.setRut(obtenerTexto(valor));
                    break;

                case "telefono":
                    existente.setTelefono(obtenerTexto(valor));
                    break;

                case "password":

                    String password = obtenerTexto(valor);

                    validarPassword(password);

                    existente.setPassword(
                            encoder.encode(password));
                    break;

                case "direccion":

                    if (valor == null) {
                        existente.setDireccion(null);
                        break;
                    }

                    if (!(valor instanceof Map<?, ?> datos)
                            || !(datos.get("id") instanceof Number direccionId)) {

                        throw new IllegalArgumentException(
                                "Direccion no valida");
                    }

                    DireccionModel direccion = new DireccionModel();

                    direccion.setId(direccionId.longValue());

                    existente.setDireccion(buscarDireccion(direccion));
                    break;

                default:
                    throw new IllegalArgumentException(
                            "Campo no permitido: " + campo);
            }
        }

        validarUsuario(existente);

        if (!correoAnterior.equalsIgnoreCase(existente.getCorreo())
                && usuarioRepository.existsByCorreo(existente.getCorreo())) {

            throw new IllegalArgumentException(
                    "El correo ya esta registrado");
        }

        if (!rutAnterior.equalsIgnoreCase(existente.getRut())
                && usuarioRepository.existsByRut(existente.getRut())) {

            throw new IllegalArgumentException(
                    "El RUT ya esta registrado");
        }

        return usuarioRepository.save(existente);
    }

    public void delete(Long id) {

        UsuarioModel existente = findById(id);

        existente.setActivo(false);

        usuarioRepository.save(existente);
    }

    private void validarUsuario(UsuarioModel usuario) {

        if (usuario.getRut() == null
                || usuario.getRut().isBlank()
                || usuario.getRut().length() > 12) {

            throw new IllegalArgumentException("RUT no valido");
        }

        if (usuario.getNombre() == null
                || usuario.getNombre().isBlank()
                || usuario.getNombre().length() > 100) {

            throw new IllegalArgumentException("Nombre no valido");
        }

        if (usuario.getApellido() == null
                || usuario.getApellido().isBlank()
                || usuario.getApellido().length() > 100) {

            throw new IllegalArgumentException("Apellido no valido");
        }

        if (usuario.getCorreo() == null
                || usuario.getCorreo().length() > 255
                || !usuario.getCorreo().matches(
                        "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {

            throw new IllegalArgumentException("Correo no valido");
        }

        if (usuario.getTelefono() != null
                && usuario.getTelefono().length() > 20) {

            throw new IllegalArgumentException("Telefono no valido");
        }
    }

    private void validarPassword(String password) {

        if (password == null
                || password.isBlank()
                || password.length() < 8
                || password.getBytes(StandardCharsets.UTF_8).length > 72) {

            throw new IllegalArgumentException(
                    "La contraseña debe tener al menos 8 caracteres y no superar 72 bytes");
        }
    }

    private void validarDuplicados(
            UsuarioModel existente, UsuarioModel usuario) {

        if (!existente.getCorreo().equalsIgnoreCase(usuario.getCorreo())
                && usuarioRepository.existsByCorreo(usuario.getCorreo())) {

            throw new IllegalArgumentException(
                    "El correo ya esta registrado");
        }

        if (!existente.getRut().equalsIgnoreCase(usuario.getRut())
                && usuarioRepository.existsByRut(usuario.getRut())) {

            throw new IllegalArgumentException(
                    "El RUT ya esta registrado");
        }
    }

    private Set<RolModel> obtenerRolCliente() {

        RolModel rol = rolRepository.findAll()
                .stream()
                .filter(r -> r.getNombre().equalsIgnoreCase("CLIENTE"))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                        "El rol CLIENTE no esta registrado"));

        Set<RolModel> roles = new HashSet<>();

        roles.add(rol);

        return roles;
    }

    private DireccionModel buscarDireccion(DireccionModel direccion) {

        if (direccion == null) {
            return null;
        }

        if (direccion.getId() == null) {
            throw new IllegalArgumentException(
                    "Debe indicar el ID de la direccion");
        }

        return direccionRepository.findById(direccion.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Direccion no encontrada"));
    }

    private String obtenerTexto(Object valor) {

        if (valor == null || valor instanceof String) {
            return (String) valor;
        }

        throw new IllegalArgumentException(
                "Debe ingresar un valor de texto");
    }
}