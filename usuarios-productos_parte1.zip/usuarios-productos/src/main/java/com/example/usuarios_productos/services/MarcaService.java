package com.example.usuarios_productos.services;

import com.example.usuarios_productos.models.MarcaModel;
import com.example.usuarios_productos.repositories.MarcaRepository;
import com.example.usuarios_productos.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class MarcaService {

    @Autowired
    private MarcaRepository marcaRepository;

    public List<MarcaModel> findAll() {
        return marcaRepository.findAll();
    }

    public MarcaModel findById(Long id) {
        return marcaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Marca no encontrada"));
    }

    public MarcaModel save(MarcaModel marca) {

        validarNombre(marca.getNombre());

        if (marcaRepository.existsByNombreIgnoreCase(marca.getNombre())) {
            throw new IllegalArgumentException(
                    "La marca ya existe");
        }

        marca.setId(null);

        return marcaRepository.save(marca);
    }

    public MarcaModel update(Long id, MarcaModel marca) {

        MarcaModel existente = findById(id);

        validarNombre(marca.getNombre());
        validarDuplicado(existente, marca.getNombre());

        existente.setNombre(marca.getNombre());

        return marcaRepository.save(existente);
    }

    public MarcaModel patch(Long id, MarcaModel marca) {

        MarcaModel existente = findById(id);

        if (marca.getNombre() != null) {

            validarNombre(marca.getNombre());
            validarDuplicado(existente, marca.getNombre());

            existente.setNombre(marca.getNombre());
        }

        return marcaRepository.save(existente);
    }

    public void delete(Long id) {
        marcaRepository.delete(findById(id));
    }

    private void validarNombre(String nombre) {

        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException(
                    "El nombre de la marca es obligatorio");
        }

        if (nombre.length() > 100) {
            throw new IllegalArgumentException(
                    "El nombre no puede superar los 100 caracteres");
        }
    }

    private void validarDuplicado(MarcaModel existente, String nombre) {

        if (!existente.getNombre().equalsIgnoreCase(nombre)
                && marcaRepository.existsByNombreIgnoreCase(nombre)) {

            throw new IllegalArgumentException(
                    "La marca ya existe");
        }
    }
}