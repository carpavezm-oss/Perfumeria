package com.example.usuarios_productos.controllers;

import com.example.usuarios_productos.models.CategoriaModel;
import com.example.usuarios_productos.services.CategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/categorias")
public class CategoriaController {

    @Autowired
    private CategoriaService categoriaService;

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<CategoriaModel>>> findAll() {

        List<EntityModel<CategoriaModel>> categorias =
                categoriaService.findAll()
                        .stream()
                        .map(this::toModel)
                        .toList();

        return ResponseEntity.ok(
                CollectionModel.of(categorias,
                        linkTo(methodOn(CategoriaController.class)
                                .findAll()).withSelfRel()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<CategoriaModel>> findById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                toModel(categoriaService.findById(id)));
    }

    @PostMapping
    public ResponseEntity<EntityModel<CategoriaModel>> save(
            @RequestBody CategoriaModel categoria) {

        CategoriaModel nueva = categoriaService.save(categoria);

        return ResponseEntity.created(
                linkTo(methodOn(CategoriaController.class)
                        .findById(nueva.getId())).toUri()
        ).body(toModel(nueva));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<CategoriaModel>> update(
            @PathVariable Long id,
            @RequestBody CategoriaModel categoria) {

        return ResponseEntity.ok(
                toModel(categoriaService.update(id, categoria)));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<EntityModel<CategoriaModel>> patch(
            @PathVariable Long id,
            @RequestBody Map<String, Object> cambios) {

        return ResponseEntity.ok(
                toModel(categoriaService.patch(id, cambios)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {

        categoriaService.delete(id);

        return ResponseEntity.noContent().build();
    }

    private EntityModel<CategoriaModel> toModel(CategoriaModel categoria) {

        return EntityModel.of(
                categoria,
                linkTo(methodOn(CategoriaController.class)
                        .findById(categoria.getId())).withSelfRel(),

                linkTo(methodOn(CategoriaController.class)
                        .findAll()).withRel("categorias")
        );
    }
}