package com.example.usuarios_productos.repositories;

import com.example.usuarios_productos.models.RegionModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RegionRepository extends JpaRepository<RegionModel, Long> {

}