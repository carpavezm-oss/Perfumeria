package com.example.usuarios_productos.repositories;

import com.example.usuarios_productos.models.MarcaModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MarcaRepository extends JpaRepository<MarcaModel, Long> {

    boolean existsByNombreIgnoreCase(String nombre);

}