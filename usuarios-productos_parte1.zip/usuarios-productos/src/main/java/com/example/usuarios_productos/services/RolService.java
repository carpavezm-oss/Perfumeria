package com.example.usuarios_productos.services;

import com.example.usuarios_productos.models.RolModel;
import com.example.usuarios_productos.repositories.RolRepository;
import com.example.usuarios_productos.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class RolService {

    @Autowired
    private RolRepository rolRepository;

    public List<RolModel> findAll() {
        return rolRepository.findAll();
    }

    public RolModel findById(Long id) {
        return rolRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Rol no encontrado"));
    }

    public RolModel save(RolModel rol) {

        validarNombre(rol.getNombre());

        rol.setId(null);

        return rolRepository.save(rol);
    }

    public RolModel update(Long id, RolModel rol) {

        RolModel existente = findById(id);

        validarNombre(rol.getNombre());

        existente.setNombre(rol.getNombre());

        return rolRepository.save(existente);
    }

    public RolModel patch(Long id, RolModel rol) {

        RolModel existente = findById(id);

        if (rol.getNombre() != null) {

            validarNombre(rol.getNombre());

            existente.setNombre(rol.getNombre());
        }

        return rolRepository.save(existente);
    }

    public void delete(Long id) {
        rolRepository.delete(findById(id));
    }

    private void validarNombre(String nombre) {

        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException(
                    "El nombre del rol es obligatorio");
        }

        if (nombre.length() > 50) {
            throw new IllegalArgumentException(
                    "El nombre no puede superar los 50 caracteres");
        }
    }
}