package com.example.usuarios_productos.services;

import com.example.usuarios_productos.models.*;
import com.example.usuarios_productos.repositories.*;
import com.example.usuarios_productos.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;

@Service
@Transactional
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private MarcaRepository marcaRepository;

    @Autowired
    private CategoriaRepository categoriaRepository;

    public List<ProductoModel> findAll() {
        return productoRepository.findAll();
    }

    public ProductoModel findById(Long id) {
        return productoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Producto no encontrado"));
    }

    public ProductoModel save(ProductoModel producto) {

        validarProducto(producto);

        producto.setId(null);

        producto.setMarca(
                buscarMarca(producto.getMarca()));

        producto.setCategorias(
                buscarCategorias(producto.getCategorias()));

        if (producto.getActivo() == null) {
            producto.setActivo(true);
        }

        return productoRepository.save(producto);
    }

    public ProductoModel update(Long id, ProductoModel producto) {

        ProductoModel existente = findById(id);

        validarProducto(producto);

        if (producto.getActivo() == null) {
            throw new IllegalArgumentException(
                    "Debe indicar el estado del producto");
        }

        existente.setNombre(producto.getNombre());
        existente.setDescripcion(producto.getDescripcion());
        existente.setPrecio(producto.getPrecio());
        existente.setStock(producto.getStock());
        existente.setActivo(producto.getActivo());

        existente.setMarca(
                buscarMarca(producto.getMarca()));

        existente.setCategorias(
                buscarCategorias(producto.getCategorias()));

        return productoRepository.save(existente);
    }

    public ProductoModel patch(Long id, Map<String, Object> cambios) {

        ProductoModel existente = findById(id);

        for (String campo : cambios.keySet()) {

            Object valor = cambios.get(campo);

            switch (campo) {

                case "nombre":
                    existente.setNombre(obtenerTexto(valor));
                    break;

                case "descripcion":
                    existente.setDescripcion(obtenerTexto(valor));
                    break;

                case "precio":
                    existente.setPrecio(obtenerEntero(valor));
                    break;

                case "stock":
                    existente.setStock(obtenerEntero(valor));
                    break;

                case "activo":
                    existente.setActivo(obtenerBooleano(valor));
                    break;

                case "marca":

                    if (!(valor instanceof Map<?, ?> datos)
                            || !(datos.get("id") instanceof Number marcaId)) {

                        throw new IllegalArgumentException(
                                "Marca no valida");
                    }

                    MarcaModel marca = new MarcaModel();

                    marca.setId(marcaId.longValue());

                    existente.setMarca(buscarMarca(marca));
                    break;

                case "categorias":

                    if (!(valor instanceof List<?> lista)) {

                        throw new IllegalArgumentException(
                                "Categorias no validas");
                    }

                    Set<CategoriaModel> categorias = new HashSet<>();

                    for (Object elemento : lista) {

                        if (!(elemento instanceof Map<?, ?> datosCategoria)
                                || !(datosCategoria.get("id")
                                instanceof Number categoriaId)) {

                            throw new IllegalArgumentException(
                                    "Categoria no valida");
                        }

                        CategoriaModel categoria = new CategoriaModel();

                        categoria.setId(categoriaId.longValue());

                        categorias.add(categoria);
                    }

                    existente.setCategorias(
                            buscarCategorias(categorias));
                    break;

                default:
                    throw new IllegalArgumentException(
                            "Campo no permitido: " + campo);
            }
        }

        validarProducto(existente);

        return productoRepository.save(existente);
    }

    public void delete(Long id) {

        ProductoModel existente = findById(id);

        existente.setActivo(false);

        productoRepository.save(existente);
    }

    public List<ProductoModel> findActivos() {
        return productoRepository.findByActivoTrue();
    }

    public List<ProductoModel> findOfertas() {

        return productoRepository
                .findByCategoriasNombreIgnoreCaseAndActivoTrue("Oferta");
    }

    public List<ProductoModel> buscarPorNombre(String nombre) {

        return productoRepository
                .findByNombreContainingIgnoreCase(nombre)
                .stream()
                .filter(p -> Boolean.TRUE.equals(p.getActivo()))
                .toList();
    }

    public List<ProductoModel> findByMarca(Long marcaId) {

        return productoRepository.findByMarcaId(marcaId)
                .stream()
                .filter(p -> Boolean.TRUE.equals(p.getActivo()))
                .toList();
    }

    public List<ProductoModel> findByCategoria(Long categoriaId) {

        return productoRepository.findByCategoriasId(categoriaId)
                .stream()
                .filter(p -> Boolean.TRUE.equals(p.getActivo()))
                .toList();
    }

    public List<ProductoModel> findByNombreCategoria(String nombre) {

        return productoRepository
                .findByCategoriasNombreIgnoreCaseAndActivoTrue(nombre);
    }

    private void validarProducto(ProductoModel producto) {

        if (producto.getNombre() == null
                || producto.getNombre().isBlank()
                || producto.getNombre().length() > 150) {

            throw new IllegalArgumentException(
                    "Nombre del producto no valido");
        }

        if (producto.getDescripcion() != null
                && producto.getDescripcion().length() > 1000) {

            throw new IllegalArgumentException(
                    "La descripcion supera los 1000 caracteres");
        }

        if (producto.getPrecio() == null
                || producto.getPrecio() <= 0) {

            throw new IllegalArgumentException(
                    "El precio debe ser mayor a cero");
        }

        if (producto.getStock() == null
                || producto.getStock() < 0) {

            throw new IllegalArgumentException(
                    "El stock no puede ser negativo");
        }

        if (producto.getMarca() == null
                || producto.getMarca().getId() == null) {

            throw new IllegalArgumentException(
                    "La marca es obligatoria");
        }

        if (producto.getCategorias() == null
                || producto.getCategorias().isEmpty()) {

            throw new IllegalArgumentException(
                    "Debe seleccionar al menos una categoria");
        }
    }

    private MarcaModel buscarMarca(MarcaModel marca) {

        if (marca == null || marca.getId() == null) {

            throw new IllegalArgumentException(
                    "La marca es obligatoria");
        }

        return marcaRepository.findById(marca.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "La marca no existe"));
    }

    private Set<CategoriaModel> buscarCategorias(
            Set<CategoriaModel> categorias) {

        Set<CategoriaModel> resultado = new HashSet<>();

        if (categorias == null || categorias.isEmpty()) {

            throw new IllegalArgumentException(
                    "Debe seleccionar al menos una categoria");
        }

        for (CategoriaModel categoria : categorias) {

            if (categoria == null || categoria.getId() == null) {

                throw new IllegalArgumentException(
                        "Categoria no valida");
            }

            CategoriaModel encontrada = categoriaRepository
                    .findById(categoria.getId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "La categoria no existe"));

            resultado.add(encontrada);
        }

        return resultado;
    }

    private Integer obtenerEntero(Object valor) {

        if (valor instanceof Integer numero) {
            return numero;
        }

        throw new IllegalArgumentException(
                "Debe ingresar un numero entero");
    }

    private Boolean obtenerBooleano(Object valor) {

        if (valor instanceof Boolean estado) {
            return estado;
        }

        throw new IllegalArgumentException(
                "Debe ingresar true o false");
    }

    private String obtenerTexto(Object valor) {

        if (valor == null || valor instanceof String) {
            return (String) valor;
        }

        throw new IllegalArgumentException(
                "Debe ingresar un valor de texto");
    }
}