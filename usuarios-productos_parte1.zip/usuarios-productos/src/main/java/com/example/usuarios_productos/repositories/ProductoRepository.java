package com.example.usuarios_productos.repositories;

import com.example.usuarios_productos.models.ProductoModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductoRepository extends JpaRepository<ProductoModel, Long> {

    List<ProductoModel> findByActivoTrue();

    List<ProductoModel> findByNombreContainingIgnoreCase(String nombre);

    List<ProductoModel> findByMarcaId(Long marcaId);

    List<ProductoModel> findByCategoriasId(Long categoriaId);

    List<ProductoModel> findByCategoriasNombreIgnoreCaseAndActivoTrue(String nombre);
}