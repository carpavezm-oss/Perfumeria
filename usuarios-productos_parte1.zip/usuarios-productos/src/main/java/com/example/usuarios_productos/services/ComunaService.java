package com.example.usuarios_productos.services;

import com.example.usuarios_productos.models.ComunaModel;
import com.example.usuarios_productos.models.RegionModel;
import com.example.usuarios_productos.repositories.ComunaRepository;
import com.example.usuarios_productos.repositories.RegionRepository;
import com.example.usuarios_productos.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ComunaService {

    @Autowired
    private ComunaRepository comunaRepository;

    @Autowired
    private RegionRepository regionRepository;

    public List<ComunaModel> findAll() {
        return comunaRepository.findAll();
    }

    public ComunaModel findById(Long id) {
        return comunaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Comuna no encontrada"));
    }

    public ComunaModel save(ComunaModel comuna) {

        validarNombre(comuna.getNombre());

        comuna.setRegion(buscarRegion(comuna.getRegion()));
        comuna.setId(null);

        return comunaRepository.save(comuna);
    }

    public ComunaModel update(Long id, ComunaModel comuna) {

        ComunaModel existente = findById(id);

        validarNombre(comuna.getNombre());

        existente.setNombre(comuna.getNombre());
        existente.setRegion(buscarRegion(comuna.getRegion()));

        return comunaRepository.save(existente);
    }

    public ComunaModel patch(Long id, ComunaModel comuna) {

        ComunaModel existente = findById(id);

        if (comuna.getNombre() != null) {
            validarNombre(comuna.getNombre());
            existente.setNombre(comuna.getNombre());
        }

        if (comuna.getRegion() != null) {
            existente.setRegion(buscarRegion(comuna.getRegion()));
        }

        return comunaRepository.save(existente);
    }

    public void delete(Long id) {
        comunaRepository.delete(findById(id));
    }

    private RegionModel buscarRegion(RegionModel region) {

        if (region == null || region.getId() == null) {
            throw new IllegalArgumentException(
                    "La region es obligatoria");
        }

        return regionRepository.findById(region.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "La region no existe"));
    }

    private void validarNombre(String nombre) {

        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException(
                    "El nombre de la comuna es obligatorio");
        }

        if (nombre.length() > 100) {
            throw new IllegalArgumentException(
                    "El nombre no puede superar los 100 caracteres");
        }
    }
}