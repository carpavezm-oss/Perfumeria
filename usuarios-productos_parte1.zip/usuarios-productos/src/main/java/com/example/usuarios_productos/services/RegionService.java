package com.example.usuarios_productos.services;

import com.example.usuarios_productos.models.RegionModel;
import com.example.usuarios_productos.repositories.RegionRepository;
import com.example.usuarios_productos.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class RegionService {

    @Autowired
    private RegionRepository regionRepository;

    public List<RegionModel> findAll() {
        return regionRepository.findAll();
    }

    public RegionModel findById(Long id) {
        return regionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Region no encontrada"));
    }

    public RegionModel save(RegionModel region) {

        validarNombre(region.getNombre());

        region.setId(null);

        return regionRepository.save(region);
    }

    public RegionModel update(Long id, RegionModel region) {

        RegionModel existente = findById(id);

        validarNombre(region.getNombre());

        existente.setNombre(region.getNombre());

        return regionRepository.save(existente);
    }

    public RegionModel patch(Long id, RegionModel region) {

        RegionModel existente = findById(id);

        if (region.getNombre() != null) {

            validarNombre(region.getNombre());

            existente.setNombre(region.getNombre());
        }

        return regionRepository.save(existente);
    }

    public void delete(Long id) {
        regionRepository.delete(findById(id));
    }

    private void validarNombre(String nombre) {

        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException(
                    "El nombre de la region es obligatorio");
        }

        if (nombre.length() > 100) {
            throw new IllegalArgumentException(
                    "El nombre no puede superar los 100 caracteres");
        }
    }
}